<?php
/**
 * Plugin Name: WooCommerce Simplified
 * Plugin URI: https://woocommercesimplified.com
 * Description: One-click WooCommerce store setup with industry-specific templates. Launch your online store in 5 minutes!
 * Version: 1.0.0
 * Author: Your Name
 * Author URI: https://yourwebsite.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: woocommerce-simplified
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * WC requires at least: 6.0
 * WC tested up to: 8.5
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Define plugin constants
define('WCS_VERSION', '1.0.0');
define('WCS_PLUGIN_FILE', __FILE__);
define('WCS_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('WCS_PLUGIN_URL', plugin_dir_url(__FILE__));
define('WCS_PLUGIN_BASENAME', plugin_basename(__FILE__));

/**
 * Main WooCommerce Simplified Class
 */
final class WooCommerce_Simplified {
    
    /**
     * Single instance of the class
     */
    protected static $_instance = null;
    
    /**
     * Main Instance
     */
    public static function instance() {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
    
    /**
     * Constructor
     */
    public function __construct() {
        $this->init_hooks();
        $this->includes();
        $this->init();
    }
    
    /**
     * Hook into actions and filters
     */
    private function init_hooks() {
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        
        add_action('plugins_loaded', array($this, 'check_dependencies'), 11);
        add_action('admin_notices', array($this, 'admin_notices'));
    }
    
    /**
     * Include required files
     */
    private function includes() {
        // Core classes
        require_once WCS_PLUGIN_DIR . 'includes/class-wcs-installer.php';
        require_once WCS_PLUGIN_DIR . 'includes/class-wcs-onboarding.php';
        require_once WCS_PLUGIN_DIR . 'includes/class-wcs-template-manager.php';
        require_once WCS_PLUGIN_DIR . 'includes/class-wcs-demo-importer.php';
        require_once WCS_PLUGIN_DIR . 'includes/class-wcs-theme-customizer.php';
        require_once WCS_PLUGIN_DIR . 'includes/class-wcs-admin.php';
        require_once WCS_PLUGIN_DIR . 'includes/class-wcs-ajax.php';
    }
    
    /**
     * Initialize the plugin
     */
    private function init() {
        // Initialize classes
        WCS_Admin::instance();
        WCS_Ajax::instance();
        
        // Load textdomain
        add_action('init', array($this, 'load_textdomain'));
    }
    
    /**
     * Load plugin textdomain
     */
    public function load_textdomain() {
        load_plugin_textdomain('woocommerce-simplified', false, dirname(WCS_PLUGIN_BASENAME) . '/languages');
    }
    
    /**
     * Check if WooCommerce is active
     */
    public function check_dependencies() {
        if (!class_exists('WooCommerce')) {
            add_action('admin_notices', array($this, 'woocommerce_missing_notice'));
            return false;
        }
        return true;
    }
    
    /**
     * WooCommerce missing notice
     */
    public function woocommerce_missing_notice() {
        $class = 'notice notice-error';
        $message = sprintf(
            __('WooCommerce Simplified requires WooCommerce to be installed and active. <a href="%s">Install WooCommerce</a>', 'woocommerce-simplified'),
            admin_url('plugin-install.php?s=woocommerce&tab=search&type=term')
        );
        printf('<div class="%1$s"><p>%2$s</p></div>', esc_attr($class), wp_kses_post($message));
    }
    
    /**
     * Admin notices
     */
    public function admin_notices() {
        // Show setup wizard notice if not completed
        if (!get_option('wcs_onboarding_complete') && current_user_can('manage_options')) {
            $wizard_url = admin_url('admin.php?page=wcs-wizard');
            ?>
            <div class="notice notice-info is-dismissible wcs-setup-notice">
                <p>
                    <strong><?php _e('Welcome to WooCommerce Simplified!', 'woocommerce-simplified'); ?></strong>
                    <?php _e('Let\'s set up your store in just 5 minutes.', 'woocommerce-simplified'); ?>
                    <a href="<?php echo esc_url($wizard_url); ?>" class="button button-primary">
                        <?php _e('Start Setup Wizard', 'woocommerce-simplified'); ?>
                    </a>
                </p>
            </div>
            <?php
        }
    }
    
    /**
     * Plugin activation
     */
    public function activate() {
        // Set default options
        if (!get_option('wcs_version')) {
            update_option('wcs_version', WCS_VERSION);
        }
        
        // Flag for redirect to wizard
        set_transient('wcs_activation_redirect', true, 30);
        
        // Run installer
        WCS_Installer::install();
    }
    
    /**
     * Plugin deactivation
     */
    public function deactivate() {
        // Clean up transients
        delete_transient('wcs_activation_redirect');
    }
}

/**
 * Returns the main instance of WooCommerce_Simplified
 */
function WCS() {
    return WooCommerce_Simplified::instance();
}

// Initialize the plugin
WCS();
