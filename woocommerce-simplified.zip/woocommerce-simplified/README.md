# WooCommerce Simplified

**Launch your professional WooCommerce store in 5 minutes!**

One-click setup wizard with industry-specific templates for WooCommerce stores.

## 🚀 Features

- **5-Minute Setup** - Complete wizard-based installation
- **9 Industry Templates** - Fashion, Food, Digital, Beauty, Home, Courses, Art, Jewelry, Services
- **Demo Products** - Pre-loaded industry-specific sample products
- **Auto Configuration** - Pages, menus, payments, shipping all configured
- **Brand Customization** - Logo and color scheme applied instantly
- **Clean Dashboard** - User-friendly admin interface
- **Demo Content Manager** - Easily remove or customize demo products

## 📁 Plugin Structure

```
woocommerce-simplified/
├── woocommerce-simplified.php     # Main plugin file
├── readme.txt                      # WordPress.org readme
├── README.md                       # This file
│
├── includes/                       # PHP classes
│   ├── class-wcs-installer.php
│   ├── class-wcs-onboarding.php
│   ├── class-wcs-template-manager.php
│   ├── class-wcs-demo-importer.php
│   ├── class-wcs-theme-customizer.php
│   ├── class-wcs-admin.php
│   └── class-wcs-ajax.php
│
├── assets/                         # Frontend assets
│   ├── css/
│   │   ├── wizard.css
│   │   └── admin.css
│   ├── js/
│   │   ├── wizard.js
│   │   └── admin.js
│   └── images/
│       └── previews/              # Template preview images
│
├── templates/                      # Industry templates
│   ├── fashion/
│   │   ├── config.php
│   │   ├── products.json
│   │   └── pages/
│   ├── food/
│   ├── digital/
│   └── ...
│
└── languages/                      # Translation files
    └── woocommerce-simplified.pot
```

## 🔧 Installation

### For Users

1. Download the plugin zip file
2. Go to WordPress Admin → Plugins → Add New
3. Click "Upload Plugin" and select the zip file
4. Activate the plugin
5. Follow the setup wizard

### For Developers

```bash
# Clone repository
cd wp-content/plugins/
git clone [repository-url] woocommerce-simplified

# Install (if using Composer for dependencies)
cd woocommerce-simplified
composer install (if applicable)

# Activate in WordPress
wp plugin activate woocommerce-simplified
```

## 💻 Development Setup

### Requirements

- WordPress 5.8+
- WooCommerce 6.0+
- PHP 7.4+
- MySQL 5.6+

### Local Development

1. Set up a local WordPress environment (Local by Flywheel, XAMPP, etc.)
2. Clone this repository into `wp-content/plugins/`
3. Activate the plugin
4. Make your changes
5. Test thoroughly

### Coding Standards

Follow WordPress Coding Standards:
- PHP: [WordPress PHP Coding Standards](https://developer.wordpress.org/coding-standards/wordpress-coding-standards/php/)
- JavaScript: [WordPress JavaScript Coding Standards](https://developer.wordpress.org/coding-standards/wordpress-coding-standards/javascript/)
- CSS: [WordPress CSS Coding Standards](https://developer.wordpress.org/coding-standards/wordpress-coding-standards/css/)

## 🎨 Adding New Industry Templates

### Step 1: Create Template Directory

```bash
mkdir templates/your-industry
```

### Step 2: Create Configuration File

Create `templates/your-industry/config.php`:

```php
<?php
return array(
    'name' => 'Your Industry Name',
    'slug' => 'your-industry',
    'theme' => 'storefront',
    'colors' => array(
        'primary' => '#000000',
        'secondary' => '#ffffff',
    ),
    'features' => array(
        'feature1' => true,
        'feature2' => true,
    ),
);
```

### Step 3: Register in Installer

Add to `includes/class-wcs-installer.php`:

```php
'your-industry' => array(
    'name' => __('Your Industry', 'woocommerce-simplified'),
    'icon' => 'dashicons-your-icon',
    'description' => __('Description', 'woocommerce-simplified'),
    'demo_products' => 10,
    'features' => array('Feature 1', 'Feature 2'),
),
```

### Step 4: Create Demo Products

Add demo products in `includes/class-wcs-demo-importer.php`:

```php
private function get_your_industry_products() {
    return array(
        array(
            'name' => 'Product Name',
            'price' => 29.99,
            // ... product data
        ),
    );
}
```

## 🧪 Testing

### Manual Testing Checklist

- [ ] Plugin activates without errors
- [ ] Setup wizard completes successfully
- [ ] All 9 industry templates install correctly
- [ ] Demo products import properly
- [ ] Pages are created with correct content
- [ ] Menus are set up and linked
- [ ] Brand colors apply correctly
- [ ] Logo upload works
- [ ] Payment methods save
- [ ] Shipping settings configure
- [ ] Dashboard displays correctly
- [ ] Demo content can be removed
- [ ] Settings page works
- [ ] Wizard can be reset

### Automated Testing (if applicable)

```bash
# Run PHPUnit tests
phpunit

# Run code sniffer
phpcs --standard=WordPress .
```

## 📝 Key Functions

### Main Plugin Class

```php
WooCommerce_Simplified::instance()
```

### Template Installation

```php
WCS_Template_Manager::install_template($industry, $settings)
```

### Demo Product Import

```php
$importer = new WCS_Demo_Importer();
$importer->import_products($industry, $settings);
```

### Remove Demo Content

```php
$importer = new WCS_Demo_Importer();
$importer->remove_demo_content();
```

## 🎯 Hooks & Filters

### Actions

```php
// After template installation
do_action('wcs_template_installed', $industry, $settings);

// After onboarding complete
do_action('wcs_onboarding_complete', $settings);

// Before demo product import
do_action('wcs_before_demo_import', $industry);
```

### Filters

```php
// Modify industry list
$industries = apply_filters('wcs_available_industries', $industries);

// Modify template config
$config = apply_filters('wcs_template_config', $config, $industry);

// Modify demo products
$products = apply_filters('wcs_demo_products', $products, $industry);
```

## 🌐 Internationalization

### Creating Translations

```bash
# Generate .pot file
wp i18n make-pot . languages/woocommerce-simplified.pot

# Translate using Poedit or similar
# Save as: languages/woocommerce-simplified-{locale}.po/.mo
```

### Using Translations

All text is wrapped in translation functions:

```php
__('Text', 'woocommerce-simplified')
_e('Text', 'woocommerce-simplified')
esc_html__('Text', 'woocommerce-simplified')
```

## 📦 Building Release

### Create Distribution Package

```bash
# Remove development files
rm -rf .git .gitignore node_modules

# Create zip
cd ..
zip -r woocommerce-simplified-1.0.0.zip woocommerce-simplified \
    -x "*/node_modules/*" "*/.*" "*/.git/*"
```

### Version Bumping

1. Update version in `woocommerce-simplified.php`
2. Update version in `readme.txt`
3. Update `WCS_VERSION` constant
4. Add changelog entry
5. Commit and tag

## 🐛 Debugging

### Enable Debug Mode

```php
// In wp-config.php
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
define('WP_DEBUG_DISPLAY', false);
```

### Common Issues

**Issue**: Wizard not loading
**Solution**: Check if WooCommerce is active

**Issue**: Demo products not importing
**Solution**: Check memory limit and execution time

**Issue**: Styles not applying
**Solution**: Clear cache and check theme compatibility

## 🤝 Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

### Contribution Guidelines

- Follow WordPress Coding Standards
- Add comments for complex logic
- Update documentation
- Test thoroughly before submitting
- One feature per pull request

## 📄 License

This plugin is licensed under the GPL v2 or later.

```
WooCommerce Simplified
Copyright (C) 2026

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
```

## 📞 Support

- **Documentation**: [Link to docs]
- **Support Forum**: [Link to forum]
- **Email**: support@example.com
- **Issues**: [GitHub Issues]

## 🎉 Credits

- Built with ❤️ for the WordPress community
- Powered by WooCommerce
- Icons from Dashicons

## 📅 Changelog

### 1.0.0 - 2026-01-31
- Initial release
- 9 industry-specific templates
- Complete setup wizard
- Demo content importer
- Brand customization
- Admin dashboard
- Demo content manager

---

**Made with ☕ by [Your Name]**
