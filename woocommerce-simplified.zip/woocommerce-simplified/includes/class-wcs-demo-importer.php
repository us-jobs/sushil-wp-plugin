<?php
/**
 * WooCommerce Simplified Demo Importer
 *
 * @package WooCommerce_Simplified
 */

if (!defined('ABSPATH')) {
    exit;
}

class WCS_Demo_Importer {
    
    /**
     * Import products for industry
     */
    public function import_products($industry, $settings = array()) {
        $products_data = $this->get_products_data($industry);
        
        if (empty($products_data)) {
            return new WP_Error('no_products', __('No demo products available for this industry', 'woocommerce-simplified'));
        }
        
        $imported = array();
        
        foreach ($products_data as $product_data) {
            $product_id = $this->create_product($product_data);
            
            if (!is_wp_error($product_id)) {
                $imported[] = $product_id;
            }
        }
        
        // Mark as demo content
        update_option('wcs_demo_content_installed', true);
        update_option('wcs_demo_product_ids', $imported);
        
        return array(
            'count' => count($imported),
            'ids' => $imported,
        );
    }
    
    /**
     * Get products data for industry
     */
    private function get_products_data($industry) {
        // In production, this would load from JSON files
        // For now, we'll return hardcoded sample data
        
        $products = array();
        
        switch ($industry) {
            case 'fashion':
                $products = $this->get_fashion_products();
                break;
            case 'food':
                $products = $this->get_food_products();
                break;
            case 'digital':
                $products = $this->get_digital_products();
                break;
            case 'beauty':
                $products = $this->get_beauty_products();
                break;
            case 'home':
                $products = $this->get_home_products();
                break;
            default:
                $products = $this->get_generic_products();
        }
        
        return $products;
    }
    
    /**
     * Fashion industry products
     */
    private function get_fashion_products() {
        return array(
            array(
                'name' => 'Classic Cotton T-Shirt',
                'description' => 'Comfortable everyday t-shirt made from 100% organic cotton. Available in multiple colors and sizes.',
                'short_description' => 'Premium organic cotton t-shirt',
                'price' => 29.99,
                'regular_price' => 29.99,
                'categories' => array('Women', 'Tops'),
                'images' => array('tshirt-1.jpg', 'tshirt-2.jpg'),
                'type' => 'variable',
                'attributes' => array(
                    'size' => array('S', 'M', 'L', 'XL'),
                    'color' => array('Black', 'White', 'Navy', 'Gray'),
                ),
                'manage_stock' => true,
                'stock_quantity' => 100,
            ),
            array(
                'name' => 'Slim Fit Jeans',
                'description' => 'Modern slim fit jeans with stretch fabric for ultimate comfort. Perfect for any occasion.',
                'short_description' => 'Comfortable stretch denim jeans',
                'price' => 79.99,
                'regular_price' => 89.99,
                'sale_price' => 79.99,
                'categories' => array('Women', 'Bottoms'),
                'images' => array('jeans-1.jpg', 'jeans-2.jpg'),
                'type' => 'variable',
                'attributes' => array(
                    'size' => array('26', '28', '30', '32', '34'),
                    'color' => array('Light Blue', 'Dark Blue', 'Black'),
                ),
                'manage_stock' => true,
                'stock_quantity' => 75,
            ),
            array(
                'name' => 'Leather Crossbody Bag',
                'description' => 'Elegant leather crossbody bag with adjustable strap. Multiple compartments for organization.',
                'short_description' => 'Premium leather handbag',
                'price' => 149.99,
                'regular_price' => 149.99,
                'categories' => array('Accessories', 'Bags'),
                'images' => array('bag-1.jpg', 'bag-2.jpg'),
                'type' => 'simple',
                'manage_stock' => true,
                'stock_quantity' => 30,
            ),
        );
    }
    
    /**
     * Food industry products
     */
    private function get_food_products() {
        return array(
            array(
                'name' => 'Margherita Pizza',
                'description' => 'Classic Italian pizza with fresh mozzarella, tomato sauce, and basil. Made with hand-tossed dough.',
                'short_description' => 'Traditional Italian pizza',
                'price' => 12.99,
                'regular_price' => 12.99,
                'categories' => array('Pizza', 'Main Course'),
                'images' => array('pizza-1.jpg'),
                'type' => 'variable',
                'attributes' => array(
                    'size' => array('Small (10")', 'Medium (12")', 'Large (16")'),
                ),
            ),
            array(
                'name' => 'Artisan Coffee Blend',
                'description' => 'Carefully selected premium coffee beans roasted to perfection. Rich and smooth flavor profile.',
                'short_description' => 'Premium coffee beans',
                'price' => 18.99,
                'regular_price' => 18.99,
                'categories' => array('Beverages', 'Coffee'),
                'images' => array('coffee-1.jpg'),
                'type' => 'simple',
                'manage_stock' => true,
                'stock_quantity' => 50,
            ),
        );
    }
    
    /**
     * Digital products
     */
    private function get_digital_products() {
        return array(
            array(
                'name' => 'Complete Web Design Course',
                'description' => 'Learn professional web design from scratch. Includes video tutorials, exercises, and project files.',
                'short_description' => 'Master web design skills',
                'price' => 99.99,
                'regular_price' => 149.99,
                'sale_price' => 99.99,
                'categories' => array('Courses', 'Design'),
                'images' => array('course-1.jpg'),
                'type' => 'simple',
                'downloadable' => true,
                'virtual' => true,
            ),
            array(
                'name' => 'Professional Resume Template Pack',
                'description' => '10 modern resume templates in multiple formats. Easy to customize in Word, Photoshop, and Illustrator.',
                'short_description' => 'Modern resume templates',
                'price' => 29.99,
                'regular_price' => 29.99,
                'categories' => array('Templates', 'Career'),
                'images' => array('resume-1.jpg'),
                'type' => 'simple',
                'downloadable' => true,
                'virtual' => true,
            ),
        );
    }
    
    /**
     * Beauty products
     */
    private function get_beauty_products() {
        return array(
            array(
                'name' => 'Hydrating Face Serum',
                'description' => 'Advanced hydrating serum with hyaluronic acid and vitamin E. Suitable for all skin types.',
                'short_description' => 'Anti-aging hydration serum',
                'price' => 49.99,
                'regular_price' => 49.99,
                'categories' => array('Skincare', 'Serums'),
                'images' => array('serum-1.jpg'),
                'type' => 'simple',
                'manage_stock' => true,
                'stock_quantity' => 60,
            ),
        );
    }
    
    /**
     * Home decor products
     */
    private function get_home_products() {
        return array(
            array(
                'name' => 'Modern Table Lamp',
                'description' => 'Elegant minimalist table lamp with adjustable brightness. Perfect for bedroom or office.',
                'short_description' => 'Minimalist desk lamp',
                'price' => 89.99,
                'regular_price' => 89.99,
                'categories' => array('Lighting', 'Home Office'),
                'images' => array('lamp-1.jpg'),
                'type' => 'simple',
                'manage_stock' => true,
                'stock_quantity' => 40,
            ),
        );
    }
    
    /**
     * Generic products
     */
    private function get_generic_products() {
        return array(
            array(
                'name' => 'Sample Product',
                'description' => 'This is a sample product to demonstrate your store.',
                'short_description' => 'Demo product',
                'price' => 49.99,
                'regular_price' => 49.99,
                'categories' => array('General'),
                'images' => array('product-1.jpg'),
                'type' => 'simple',
            ),
        );
    }
    
    /**
     * Create a single product
     */
    private function create_product($data) {
        // Determine product type
        $type = isset($data['type']) ? $data['type'] : 'simple';
        
        if ($type === 'variable' && !empty($data['attributes'])) {
            return $this->create_variable_product($data);
        } else {
            return $this->create_simple_product($data);
        }
    }
    
    /**
     * Create simple product
     */
    private function create_simple_product($data) {
        $product = new WC_Product_Simple();
        
        // Basic details
        $product->set_name($data['name']);
        $product->set_description($data['description']);
        $product->set_short_description($data['short_description']);
        
        // Pricing
        $product->set_regular_price($data['regular_price']);
        if (!empty($data['sale_price'])) {
            $product->set_sale_price($data['sale_price']);
        }
        
        // Categories
        if (!empty($data['categories'])) {
            $category_ids = $this->get_or_create_categories($data['categories']);
            $product->set_category_ids($category_ids);
        }
        
        // Stock management
        if (!empty($data['manage_stock'])) {
            $product->set_manage_stock(true);
            $product->set_stock_quantity($data['stock_quantity']);
            $product->set_stock_status('instock');
        }
        
        // Digital product settings
        if (!empty($data['downloadable'])) {
            $product->set_downloadable(true);
        }
        if (!empty($data['virtual'])) {
            $product->set_virtual(true);
        }
        
        // Save product
        $product_id = $product->save();
        
        // Mark as demo
        update_post_meta($product_id, '_wcs_demo_product', 1);
        
        // Add placeholder image
        $this->add_product_images($product_id, $data);
        
        return $product_id;
    }
    
    /**
     * Create variable product
     */
    private function create_variable_product($data) {
        $product = new WC_Product_Variable();
        
        // Basic details
        $product->set_name($data['name']);
        $product->set_description($data['description']);
        $product->set_short_description($data['short_description']);
        
        // Categories
        if (!empty($data['categories'])) {
            $category_ids = $this->get_or_create_categories($data['categories']);
            $product->set_category_ids($category_ids);
        }
        
        // Save product first
        $product_id = $product->save();
        
        // Create attributes
        $attributes = array();
        foreach ($data['attributes'] as $attr_name => $attr_values) {
            $attribute = new WC_Product_Attribute();
            $attribute->set_name($attr_name);
            $attribute->set_options($attr_values);
            $attribute->set_visible(true);
            $attribute->set_variation(true);
            $attributes[] = $attribute;
        }
        
        $product->set_attributes($attributes);
        $product->save();
        
        // Create variations
        $this->create_variations($product_id, $data);
        
        // Mark as demo
        update_post_meta($product_id, '_wcs_demo_product', 1);
        
        // Add placeholder image
        $this->add_product_images($product_id, $data);
        
        return $product_id;
    }
    
    /**
     * Create product variations
     */
    private function create_variations($product_id, $data) {
        $attributes = $data['attributes'];
        $base_price = $data['regular_price'];
        
        // Get first value of each attribute for demo variation
        $variation_attributes = array();
        foreach ($attributes as $attr_name => $attr_values) {
            $variation_attributes[sanitize_title($attr_name)] = $attr_values[0];
        }
        
        // Create one sample variation
        $variation = new WC_Product_Variation();
        $variation->set_parent_id($product_id);
        $variation->set_regular_price($base_price);
        
        if (!empty($data['sale_price'])) {
            $variation->set_sale_price($data['sale_price']);
        }
        
        $variation->set_attributes($variation_attributes);
        
        if (!empty($data['manage_stock'])) {
            $variation->set_manage_stock(true);
            $variation->set_stock_quantity($data['stock_quantity']);
        }
        
        $variation->save();
    }
    
    /**
     * Get or create product categories
     */
    private function get_or_create_categories($category_names) {
        $category_ids = array();
        
        foreach ($category_names as $name) {
            $term = term_exists($name, 'product_cat');
            
            if (!$term) {
                $term = wp_insert_term($name, 'product_cat');
            }
            
            if (!is_wp_error($term)) {
                $category_ids[] = $term['term_id'];
            }
        }
        
        return $category_ids;
    }
    
    /**
     * Add product images (placeholder)
     */
    private function add_product_images($product_id, $data) {
        // In production, you would download and attach real images
        // For now, we'll use WooCommerce's placeholder
        
        if (!empty($data['images'])) {
            // Use WooCommerce placeholder
            $placeholder_id = get_option('woocommerce_placeholder_image', 0);
            
            if ($placeholder_id) {
                set_post_thumbnail($product_id, $placeholder_id);
            }
        }
    }
    
    /**
     * Remove all demo content
     */
    public function remove_demo_content() {
        $demo_product_ids = get_option('wcs_demo_product_ids', array());
        
        foreach ($demo_product_ids as $product_id) {
            wp_delete_post($product_id, true);
        }
        
        delete_option('wcs_demo_content_installed');
        delete_option('wcs_demo_product_ids');
        
        return count($demo_product_ids);
    }
}
