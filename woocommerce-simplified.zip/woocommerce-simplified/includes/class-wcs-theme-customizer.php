<?php
/**
 * WooCommerce Simplified Theme Customizer
 *
 * @package WooCommerce_Simplified
 */

if (!defined('ABSPATH')) {
    exit;
}

class WCS_Theme_Customizer {
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('wp_enqueue_scripts', array($this, 'enqueue_custom_styles'));
        add_action('customize_register', array($this, 'register_customizer_settings'));
    }
    
    /**
     * Enqueue custom styles based on brand colors
     */
    public function enqueue_custom_styles() {
        $primary_color = get_option('wcs_primary_color', '#FF6B6B');
        $secondary_color = get_option('wcs_secondary_color', '#4ECDC4');
        
        if (!$primary_color && !$secondary_color) {
            return;
        }
        
        $custom_css = $this->generate_custom_css($primary_color, $secondary_color);
        wp_add_inline_style('storefront-style', $custom_css);
    }
    
    /**
     * Generate custom CSS
     */
    private function generate_custom_css($primary, $secondary) {
        $css = "
        /* WooCommerce Simplified Brand Colors */
        :root {
            --wcs-primary: {$primary};
            --wcs-secondary: {$secondary};
        }
        
        /* Primary color applications */
        .woocommerce-Button.button,
        .woocommerce button.button,
        .woocommerce a.button,
        .woocommerce #respond input#submit,
        .woocommerce input.button,
        button.button.alt,
        a.button.alt,
        button.button.loading {
            background-color: {$primary} !important;
            border-color: {$primary} !important;
        }
        
        .woocommerce-Button.button:hover,
        .woocommerce button.button:hover,
        .woocommerce a.button:hover,
        .woocommerce #respond input#submit:hover,
        .woocommerce input.button:hover {
            background-color: " . $this->adjust_brightness($primary, -20) . " !important;
        }
        
        /* Links and accents */
        a,
        .site-title a,
        .main-navigation a:hover,
        .woocommerce-MyAccount-navigation li.is-active a,
        .woocommerce .star-rating span,
        .price ins .amount,
        .price > .amount {
            color: {$primary};
        }
        
        /* Secondary color */
        .woocommerce-info,
        .woocommerce-message {
            border-top-color: {$secondary};
        }
        
        .woocommerce-info::before,
        .woocommerce-message::before {
            color: {$secondary};
        }
        
        /* Product badges */
        .onsale,
        .woocommerce span.onsale {
            background-color: {$secondary};
        }
        
        /* Navigation */
        .main-navigation ul.menu > li.current-menu-item > a,
        .main-navigation ul.menu > li.current-menu-ancestor > a {
            color: {$primary};
        }
        
        /* Widgets */
        .widget a:hover,
        .widget-area .widget a:hover {
            color: {$secondary};
        }
        ";
        
        return $css;
    }
    
    /**
     * Adjust color brightness
     */
    private function adjust_brightness($hex, $steps) {
        // Remove # if present
        $hex = str_replace('#', '', $hex);
        
        // Convert to RGB
        $r = hexdec(substr($hex, 0, 2));
        $g = hexdec(substr($hex, 2, 2));
        $b = hexdec(substr($hex, 4, 2));
        
        // Adjust
        $r = max(0, min(255, $r + $steps));
        $g = max(0, min(255, $g + $steps));
        $b = max(0, min(255, $b + $steps));
        
        // Convert back to hex
        return '#' . str_pad(dechex($r), 2, '0', STR_PAD_LEFT) .
                     str_pad(dechex($g), 2, '0', STR_PAD_LEFT) .
                     str_pad(dechex($b), 2, '0', STR_PAD_LEFT);
    }
    
    /**
     * Register customizer settings
     */
    public function register_customizer_settings($wp_customize) {
        // Add WCS section
        $wp_customize->add_section('wcs_branding', array(
            'title' => __('Store Branding', 'woocommerce-simplified'),
            'priority' => 30,
        ));
        
        // Primary color
        $wp_customize->add_setting('wcs_primary_color', array(
            'default' => '#FF6B6B',
            'sanitize_callback' => 'sanitize_hex_color',
        ));
        
        $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'wcs_primary_color', array(
            'label' => __('Primary Brand Color', 'woocommerce-simplified'),
            'section' => 'wcs_branding',
            'settings' => 'wcs_primary_color',
        )));
        
        // Secondary color
        $wp_customize->add_setting('wcs_secondary_color', array(
            'default' => '#4ECDC4',
            'sanitize_callback' => 'sanitize_hex_color',
        ));
        
        $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'wcs_secondary_color', array(
            'label' => __('Secondary Brand Color', 'woocommerce-simplified'),
            'section' => 'wcs_branding',
            'settings' => 'wcs_secondary_color',
        )));
    }
}

// Initialize
new WCS_Theme_Customizer();
