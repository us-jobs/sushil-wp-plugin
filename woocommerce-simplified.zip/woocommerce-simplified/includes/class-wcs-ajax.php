<?php
/**
 * WooCommerce Simplified AJAX Handler
 *
 * @package WooCommerce_Simplified
 */

if (!defined('ABSPATH')) {
    exit;
}

class WCS_Ajax {
    
    /**
     * Single instance
     */
    protected static $_instance = null;
    
    /**
     * Get instance
     */
    public static function instance() {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
    
    /**
     * Constructor
     */
    public function __construct() {
        // Wizard actions
        add_action('wp_ajax_wcs_save_wizard_step', array($this, 'save_wizard_step'));
        add_action('wp_ajax_wcs_install_template', array($this, 'install_template'));
        add_action('wp_ajax_wcs_get_industry_preview', array($this, 'get_industry_preview'));
        
        // Admin actions
        add_action('wp_ajax_wcs_remove_demo_content', array($this, 'remove_demo_content'));
        add_action('wp_ajax_wcs_reset_wizard', array($this, 'reset_wizard'));
    }
    
    /**
     * Save wizard step data
     */
    public function save_wizard_step() {
        check_ajax_referer('wcs-wizard', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Permission denied', 'woocommerce-simplified')));
        }
        
        $step = isset($_POST['step']) ? sanitize_key($_POST['step']) : '';
        $data = isset($_POST['data']) ? $_POST['data'] : array();
        
        switch ($step) {
            case 'industry':
                $this->save_industry_step($data);
                break;
                
            case 'details':
                $this->save_details_step($data);
                break;
                
            case 'settings':
                $this->save_settings_step($data);
                break;
                
            case 'payment':
                $this->save_payment_step($data);
                break;
        }
        
        wp_send_json_success(array(
            'message' => __('Step saved successfully', 'woocommerce-simplified'),
        ));
    }
    
    /**
     * Save industry selection
     */
    private function save_industry_step($data) {
        if (!empty($data['industry'])) {
            update_option('wcs_industry', sanitize_key($data['industry']));
        }
        
        if (!empty($data['start_mode'])) {
            update_option('wcs_start_mode', sanitize_key($data['start_mode']));
        }
    }
    
    /**
     * Save store details
     */
    private function save_details_step($data) {
        if (!empty($data['store_name'])) {
            update_option('wcs_store_name', sanitize_text_field($data['store_name']));
        }
        
        if (!empty($data['store_tagline'])) {
            update_option('wcs_store_tagline', sanitize_text_field($data['store_tagline']));
        }
        
        if (!empty($data['logo_id'])) {
            update_option('wcs_logo_id', absint($data['logo_id']));
        }
        
        if (!empty($data['primary_color'])) {
            update_option('wcs_primary_color', sanitize_hex_color($data['primary_color']));
        }
        
        if (!empty($data['secondary_color'])) {
            update_option('wcs_secondary_color', sanitize_hex_color($data['secondary_color']));
        }
    }
    
    /**
     * Save business settings
     */
    private function save_settings_step($data) {
        $settings = array(
            'currency' => sanitize_text_field($data['currency'] ?? 'USD'),
            'country' => sanitize_text_field($data['country'] ?? 'US'),
            'offer_physical' => !empty($data['offer_physical']),
            'offer_digital' => !empty($data['offer_digital']),
            'offer_services' => !empty($data['offer_services']),
            'shipping_type' => sanitize_key($data['shipping_type'] ?? 'flat'),
            'flat_rate' => floatval($data['flat_rate'] ?? 5.00),
        );
        
        update_option('wcs_business_settings', $settings);
    }
    
    /**
     * Save payment settings
     */
    private function save_payment_step($data) {
        $payment_methods = array(
            'stripe' => !empty($data['payment_stripe']),
            'paypal' => !empty($data['payment_paypal']),
            'bank' => !empty($data['payment_bank']),
            'cod' => !empty($data['payment_cod']),
        );
        
        update_option('wcs_payment_methods', $payment_methods);
    }
    
    /**
     * Install template (main installation process)
     */
    public function install_template() {
        check_ajax_referer('wcs-wizard', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Permission denied', 'woocommerce-simplified')));
        }
        
        // Get all saved settings
        $industry = get_option('wcs_industry');
        $start_mode = get_option('wcs_start_mode', 'fresh');
        
        $settings = array(
            'store_name' => get_option('wcs_store_name'),
            'store_tagline' => get_option('wcs_store_tagline'),
            'logo_id' => get_option('wcs_logo_id'),
            'primary_color' => get_option('wcs_primary_color'),
            'secondary_color' => get_option('wcs_secondary_color'),
            'skip_demo_products' => ($start_mode === 'existing'),
        );
        
        // Merge business settings
        $business_settings = get_option('wcs_business_settings', array());
        $settings = array_merge($settings, $business_settings);
        
        // Merge payment settings
        $payment_methods = get_option('wcs_payment_methods', array());
        $settings['payment_methods'] = $payment_methods;
        
        // Start installation
        $result = WCS_Template_Manager::install_template($industry, $settings);
        
        if (is_wp_error($result)) {
            wp_send_json_error(array(
                'message' => $result->get_error_message(),
            ));
        }
        
        // Mark onboarding as complete
        update_option('wcs_onboarding_complete', true);
        
        wp_send_json_success(array(
            'message' => __('Store installed successfully!', 'woocommerce-simplified'),
            'redirect' => admin_url('admin.php?page=wcs-dashboard'),
        ));
    }
    
    /**
     * Get industry preview data
     */
    public function get_industry_preview() {
        check_ajax_referer('wcs-wizard', 'nonce');
        
        $industry = isset($_POST['industry']) ? sanitize_key($_POST['industry']) : '';
        
        if (!$industry) {
            wp_send_json_error(array('message' => __('Invalid industry', 'woocommerce-simplified')));
        }
        
        $industries = WCS_Installer::get_industries();
        
        if (!isset($industries[$industry])) {
            wp_send_json_error(array('message' => __('Industry not found', 'woocommerce-simplified')));
        }
        
        $industry_data = $industries[$industry];
        
        // Add preview image URL
        $preview_image = WCS_PLUGIN_URL . 'assets/images/previews/' . $industry . '.jpg';
        
        wp_send_json_success(array(
            'industry' => $industry_data,
            'preview_image' => $preview_image,
        ));
    }
    
    /**
     * Remove demo content
     */
    public function remove_demo_content() {
        check_ajax_referer('wcs-admin', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Permission denied', 'woocommerce-simplified')));
        }
        
        $demo_importer = new WCS_Demo_Importer();
        $count = $demo_importer->remove_demo_content();
        
        wp_send_json_success(array(
            'message' => sprintf(__('%d demo products removed successfully', 'woocommerce-simplified'), $count),
        ));
    }
    
    /**
     * Reset wizard
     */
    public function reset_wizard() {
        check_ajax_referer('wcs-admin', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Permission denied', 'woocommerce-simplified')));
        }
        
        // Reset all wizard-related options
        delete_option('wcs_onboarding_complete');
        delete_option('wcs_industry');
        delete_option('wcs_start_mode');
        delete_option('wcs_store_name');
        delete_option('wcs_store_tagline');
        delete_option('wcs_logo_id');
        delete_option('wcs_primary_color');
        delete_option('wcs_secondary_color');
        delete_option('wcs_business_settings');
        delete_option('wcs_payment_methods');
        delete_option('wcs_template_installed');
        
        wp_send_json_success(array(
            'message' => __('Wizard reset successfully', 'woocommerce-simplified'),
            'redirect' => admin_url('admin.php?page=wcs-wizard'),
        ));
    }
}
