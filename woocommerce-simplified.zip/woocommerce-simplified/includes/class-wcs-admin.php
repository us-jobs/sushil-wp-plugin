<?php
/**
 * WooCommerce Simplified Admin
 *
 * @package WooCommerce_Simplified
 */

if (!defined('ABSPATH')) {
    exit;
}

class WCS_Admin {
    
    /**
     * Single instance
     */
    protected static $_instance = null;
    
    /**
     * Get instance
     */
    public static function instance() {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
        
        // Initialize onboarding
        new WCS_Onboarding();
    }
    
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        // Main dashboard page
        add_menu_page(
            __('WooCommerce Simplified', 'woocommerce-simplified'),
            __('Store Builder', 'woocommerce-simplified'),
            'manage_options',
            'wcs-dashboard',
            array($this, 'render_dashboard'),
            'dashicons-store',
            56
        );
        
        // Submenu items
        add_submenu_page(
            'wcs-dashboard',
            __('Dashboard', 'woocommerce-simplified'),
            __('Dashboard', 'woocommerce-simplified'),
            'manage_options',
            'wcs-dashboard',
            array($this, 'render_dashboard')
        );
        
        add_submenu_page(
            'wcs-dashboard',
            __('Demo Content', 'woocommerce-simplified'),
            __('Demo Content', 'woocommerce-simplified'),
            'manage_options',
            'wcs-demo-content',
            array($this, 'render_demo_content_page')
        );
        
        add_submenu_page(
            'wcs-dashboard',
            __('Settings', 'woocommerce-simplified'),
            __('Settings', 'woocommerce-simplified'),
            'manage_options',
            'wcs-settings',
            array($this, 'render_settings_page')
        );
    }
    
    /**
     * Enqueue admin assets
     */
    public function enqueue_admin_assets($hook) {
        // Only load on our pages
        if (strpos($hook, 'wcs-') === false && $hook !== 'toplevel_page_wcs-dashboard') {
            return;
        }
        
        wp_enqueue_style('wcs-admin', WCS_PLUGIN_URL . 'assets/css/admin.css', array(), WCS_VERSION);
        wp_enqueue_script('wcs-admin', WCS_PLUGIN_URL . 'assets/js/admin.js', array('jquery'), WCS_VERSION, true);
        
        // Color picker
        wp_enqueue_style('wp-color-picker');
        wp_enqueue_script('wp-color-picker');
        
        // Media uploader
        wp_enqueue_media();
        
        // Localize script
        wp_localize_script('wcs-admin', 'wcsAdmin', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('wcs-admin'),
            'strings' => array(
                'confirm_remove_demo' => __('Are you sure you want to remove all demo content? This cannot be undone.', 'woocommerce-simplified'),
                'removing' => __('Removing...', 'woocommerce-simplified'),
                'removed' => __('Demo content removed successfully', 'woocommerce-simplified'),
            ),
        ));
    }
    
    /**
     * Render dashboard page
     */
    public function render_dashboard() {
        $onboarding_complete = get_option('wcs_onboarding_complete');
        $industry = get_option('wcs_industry');
        $demo_installed = get_option('wcs_demo_content_installed');
        
        ?>
        <div class="wrap wcs-dashboard">
            <h1><?php _e('WooCommerce Simplified Dashboard', 'woocommerce-simplified'); ?></h1>
            
            <?php if (!$onboarding_complete): ?>
                <div class="notice notice-warning">
                    <p>
                        <strong><?php _e('Setup not complete', 'woocommerce-simplified'); ?></strong>
                        <?php _e('Please complete the setup wizard to get started.', 'woocommerce-simplified'); ?>
                        <a href="<?php echo admin_url('admin.php?page=wcs-wizard'); ?>" class="button button-primary">
                            <?php _e('Continue Setup', 'woocommerce-simplified'); ?>
                        </a>
                    </p>
                </div>
            <?php else: ?>
                
                <div class="wcs-welcome-panel">
                    <div class="welcome-panel-content">
                        <h2><?php _e('Welcome to Your Store!', 'woocommerce-simplified'); ?></h2>
                        <p class="about-description">
                            <?php printf(__('Your %s store is ready to go. Here are some quick actions to get you started.', 'woocommerce-simplified'), esc_html($industry)); ?>
                        </p>
                        
                        <div class="welcome-panel-column-container">
                            <div class="welcome-panel-column">
                                <h3><?php _e('Get Started', 'woocommerce-simplified'); ?></h3>
                                <a href="<?php echo admin_url('post-new.php?post_type=product'); ?>" class="button button-primary button-hero">
                                    <?php _e('Add Your First Product', 'woocommerce-simplified'); ?>
                                </a>
                                <p><?php _e('Or customize the demo products we\'ve added for you', 'woocommerce-simplified'); ?></p>
                            </div>
                            
                            <div class="welcome-panel-column">
                                <h3><?php _e('Customize', 'woocommerce-simplified'); ?></h3>
                                <ul>
                                    <li><a href="<?php echo admin_url('customize.php'); ?>" class="welcome-icon dashicons-admin-appearance"><?php _e('Customize Design', 'woocommerce-simplified'); ?></a></li>
                                    <li><a href="<?php echo admin_url('nav-menus.php'); ?>" class="welcome-icon dashicons-menu"><?php _e('Edit Menus', 'woocommerce-simplified'); ?></a></li>
                                    <li><a href="<?php echo admin_url('admin.php?page=wc-settings'); ?>" class="welcome-icon dashicons-admin-settings"><?php _e('Store Settings', 'woocommerce-simplified'); ?></a></li>
                                </ul>
                            </div>
                            
                            <div class="welcome-panel-column welcome-panel-last">
                                <h3><?php _e('Launch', 'woocommerce-simplified'); ?></h3>
                                <ul>
                                    <li><a href="<?php echo home_url('/'); ?>" target="_blank" class="welcome-icon dashicons-visibility"><?php _e('Preview Store', 'woocommerce-simplified'); ?></a></li>
                                    <li><a href="<?php echo admin_url('admin.php?page=wc-reports'); ?>" class="welcome-icon dashicons-chart-line"><?php _e('View Reports', 'woocommerce-simplified'); ?></a></li>
                                    <li><a href="<?php echo admin_url('edit.php?post_type=shop_order'); ?>" class="welcome-icon dashicons-cart"><?php _e('Manage Orders', 'woocommerce-simplified'); ?></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                
                <?php if ($demo_installed): ?>
                    <div class="wcs-info-box">
                        <div class="wcs-info-box-icon">
                            <span class="dashicons dashicons-info"></span>
                        </div>
                        <div class="wcs-info-box-content">
                            <h3><?php _e('Demo Content Installed', 'woocommerce-simplified'); ?></h3>
                            <p><?php _e('Your store includes demo products to help you get started. You can customize or replace them anytime.', 'woocommerce-simplified'); ?></p>
                            <a href="<?php echo admin_url('admin.php?page=wcs-demo-content'); ?>" class="button">
                                <?php _e('Manage Demo Content', 'woocommerce-simplified'); ?>
                            </a>
                        </div>
                    </div>
                <?php endif; ?>
                
                <div class="wcs-quick-stats">
                    <h2><?php _e('Quick Stats', 'woocommerce-simplified'); ?></h2>
                    <div class="wcs-stats-grid">
                        <?php
                        $product_count = wp_count_posts('product')->publish;
                        $order_count = wc_orders_count('completed');
                        ?>
                        
                        <div class="wcs-stat-card">
                            <div class="stat-icon"><span class="dashicons dashicons-products"></span></div>
                            <div class="stat-number"><?php echo esc_html($product_count); ?></div>
                            <div class="stat-label"><?php _e('Products', 'woocommerce-simplified'); ?></div>
                        </div>
                        
                        <div class="wcs-stat-card">
                            <div class="stat-icon"><span class="dashicons dashicons-cart"></span></div>
                            <div class="stat-number"><?php echo esc_html($order_count); ?></div>
                            <div class="stat-label"><?php _e('Orders', 'woocommerce-simplified'); ?></div>
                        </div>
                        
                        <div class="wcs-stat-card">
                            <div class="stat-icon"><span class="dashicons dashicons-admin-page"></span></div>
                            <div class="stat-number"><?php echo esc_html(wp_count_posts('page')->publish); ?></div>
                            <div class="stat-label"><?php _e('Pages', 'woocommerce-simplified'); ?></div>
                        </div>
                    </div>
                </div>
                
            <?php endif; ?>
        </div>
        <?php
    }
    
    /**
     * Render demo content management page
     */
    public function render_demo_content_page() {
        $demo_installed = get_option('wcs_demo_content_installed');
        $demo_product_ids = get_option('wcs_demo_product_ids', array());
        
        ?>
        <div class="wrap wcs-demo-content">
            <h1><?php _e('Demo Content Management', 'woocommerce-simplified'); ?></h1>
            
            <?php if ($demo_installed): ?>
                <div class="wcs-demo-content-box">
                    <h2><?php _e('Demo Products Installed', 'woocommerce-simplified'); ?></h2>
                    <p><?php printf(__('You have %d demo products installed. These are sample products to help you visualize your store.', 'woocommerce-simplified'), count($demo_product_ids)); ?></p>
                    
                    <h3><?php _e('Options', 'woocommerce-simplified'); ?></h3>
                    
                    <div class="wcs-demo-options">
                        <div class="demo-option">
                            <h4><?php _e('Keep Demo Products', 'woocommerce-simplified'); ?></h4>
                            <p><?php _e('Use them as templates and customize them with your own information.', 'woocommerce-simplified'); ?></p>
                            <a href="<?php echo admin_url('edit.php?post_type=product'); ?>" class="button">
                                <?php _e('Edit Products', 'woocommerce-simplified'); ?>
                            </a>
                        </div>
                        
                        <div class="demo-option">
                            <h4><?php _e('Remove All Demo Content', 'woocommerce-simplified'); ?></h4>
                            <p><?php _e('Start with a clean slate and add your own products from scratch.', 'woocommerce-simplified'); ?></p>
                            <button type="button" class="button button-secondary" id="wcs-remove-demo">
                                <?php _e('Remove All Demo Products', 'woocommerce-simplified'); ?>
                            </button>
                        </div>
                        
                        <div class="demo-option">
                            <h4><?php _e('Replace Gradually', 'woocommerce-simplified'); ?></h4>
                            <p><?php _e('Add your products one by one and delete demos as you go.', 'woocommerce-simplified'); ?></p>
                            <a href="<?php echo admin_url('post-new.php?post_type=product'); ?>" class="button button-primary">
                                <?php _e('Add New Product', 'woocommerce-simplified'); ?>
                            </a>
                        </div>
                    </div>
                    
                    <div class="wcs-demo-products-list">
                        <h3><?php _e('Demo Products', 'woocommerce-simplified'); ?></h3>
                        <table class="wp-list-table widefat fixed striped">
                            <thead>
                                <tr>
                                    <th><?php _e('Product', 'woocommerce-simplified'); ?></th>
                                    <th><?php _e('Price', 'woocommerce-simplified'); ?></th>
                                    <th><?php _e('Stock', 'woocommerce-simplified'); ?></th>
                                    <th><?php _e('Actions', 'woocommerce-simplified'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($demo_product_ids as $product_id): ?>
                                    <?php $product = wc_get_product($product_id); ?>
                                    <?php if ($product): ?>
                                        <tr>
                                            <td><strong><?php echo esc_html($product->get_name()); ?></strong></td>
                                            <td><?php echo wp_kses_post($product->get_price_html()); ?></td>
                                            <td><?php echo $product->is_in_stock() ? __('In stock', 'woocommerce-simplified') : __('Out of stock', 'woocommerce-simplified'); ?></td>
                                            <td>
                                                <a href="<?php echo get_edit_post_link($product_id); ?>" class="button button-small">
                                                    <?php _e('Edit', 'woocommerce-simplified'); ?>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php else: ?>
                <div class="notice notice-info">
                    <p><?php _e('No demo content is currently installed.', 'woocommerce-simplified'); ?></p>
                </div>
            <?php endif; ?>
        </div>
        <?php
    }
    
    /**
     * Render settings page
     */
    public function render_settings_page() {
        if (isset($_POST['wcs_save_settings']) && check_admin_referer('wcs-settings')) {
            $this->save_settings();
            echo '<div class="notice notice-success"><p>' . __('Settings saved.', 'woocommerce-simplified') . '</p></div>';
        }
        
        $store_name = get_option('wcs_store_name', get_bloginfo('name'));
        $primary_color = get_option('wcs_primary_color', '#FF6B6B');
        $secondary_color = get_option('wcs_secondary_color', '#4ECDC4');
        
        ?>
        <div class="wrap wcs-settings">
            <h1><?php _e('WooCommerce Simplified Settings', 'woocommerce-simplified'); ?></h1>
            
            <form method="post" action="">
                <?php wp_nonce_field('wcs-settings'); ?>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="store_name"><?php _e('Store Name', 'woocommerce-simplified'); ?></label>
                        </th>
                        <td>
                            <input type="text" id="store_name" name="store_name" value="<?php echo esc_attr($store_name); ?>" class="regular-text">
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="primary_color"><?php _e('Primary Color', 'woocommerce-simplified'); ?></label>
                        </th>
                        <td>
                            <input type="text" id="primary_color" name="primary_color" value="<?php echo esc_attr($primary_color); ?>" class="wcs-color-field">
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="secondary_color"><?php _e('Secondary Color', 'woocommerce-simplified'); ?></label>
                        </th>
                        <td>
                            <input type="text" id="secondary_color" name="secondary_color" value="<?php echo esc_attr($secondary_color); ?>" class="wcs-color-field">
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <button type="submit" name="wcs_save_settings" class="button button-primary">
                        <?php _e('Save Settings', 'woocommerce-simplified'); ?>
                    </button>
                </p>
            </form>
            
            <hr>
            
            <h2><?php _e('Reset Plugin', 'woocommerce-simplified'); ?></h2>
            <p><?php _e('Start the setup wizard again from the beginning.', 'woocommerce-simplified'); ?></p>
            <button type="button" class="button" id="wcs-reset-wizard">
                <?php _e('Reset Setup Wizard', 'woocommerce-simplified'); ?>
            </button>
        </div>
        <?php
    }
    
    /**
     * Save settings
     */
    private function save_settings() {
        if (isset($_POST['store_name'])) {
            update_option('wcs_store_name', sanitize_text_field($_POST['store_name']));
            update_option('blogname', sanitize_text_field($_POST['store_name']));
        }
        
        if (isset($_POST['primary_color'])) {
            update_option('wcs_primary_color', sanitize_hex_color($_POST['primary_color']));
        }
        
        if (isset($_POST['secondary_color'])) {
            update_option('wcs_secondary_color', sanitize_hex_color($_POST['secondary_color']));
        }
    }
}
