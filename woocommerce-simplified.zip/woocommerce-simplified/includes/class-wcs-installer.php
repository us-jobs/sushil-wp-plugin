<?php
/**
 * WooCommerce Simplified Installer
 *
 * @package WooCommerce_Simplified
 */

if (!defined('ABSPATH')) {
    exit;
}

class WCS_Installer {
    
    /**
     * Install plugin
     */
    public static function install() {
        if (!is_blog_installed()) {
            return;
        }
        
        // Check if already installed
        if (self::is_installed()) {
            self::update();
            return;
        }
        
        self::create_options();
        self::create_tables();
        
        update_option('wcs_version', WCS_VERSION);
        update_option('wcs_install_date', current_time('mysql'));
    }
    
    /**
     * Check if plugin is installed
     */
    private static function is_installed() {
        return (bool) get_option('wcs_version');
    }
    
    /**
     * Update plugin
     */
    private static function update() {
        $current_version = get_option('wcs_version');
        
        if (version_compare($current_version, WCS_VERSION, '<')) {
            // Run update routines
            update_option('wcs_version', WCS_VERSION);
        }
    }
    
    /**
     * Create default options
     */
    private static function create_options() {
        $defaults = array(
            'wcs_onboarding_complete' => false,
            'wcs_industry' => '',
            'wcs_store_name' => get_bloginfo('name'),
            'wcs_store_tagline' => get_bloginfo('description'),
            'wcs_primary_color' => '#FF6B6B',
            'wcs_secondary_color' => '#4ECDC4',
            'wcs_template_installed' => false,
            'wcs_demo_content_installed' => false,
        );
        
        foreach ($defaults as $key => $value) {
            if (!get_option($key)) {
                add_option($key, $value);
            }
        }
    }
    
    /**
     * Create custom database tables if needed
     */
    private static function create_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // Example: Create analytics table for tracking
        $sql = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}wcs_analytics (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            event_type varchar(50) NOT NULL,
            event_data longtext,
            user_id bigint(20),
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY event_type (event_type),
            KEY user_id (user_id)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
    
    /**
     * Get available industries
     */
    public static function get_industries() {
        return array(
            'fashion' => array(
                'name' => __('Fashion & Apparel', 'woocommerce-simplified'),
                'icon' => 'dashicons-store',
                'description' => __('Clothing, shoes, and accessories', 'woocommerce-simplified'),
                'demo_products' => 12,
                'features' => array('Size variations', 'Color swatches', 'Size guide', 'Lookbook gallery'),
            ),
            'food' => array(
                'name' => __('Food & Beverage', 'woocommerce-simplified'),
                'icon' => 'dashicons-food',
                'description' => __('Restaurants, bakeries, and food delivery', 'woocommerce-simplified'),
                'demo_products' => 15,
                'features' => array('Menu layouts', 'Allergen info', 'Delivery options', 'Opening hours'),
            ),
            'digital' => array(
                'name' => __('Digital Products', 'woocommerce-simplified'),
                'icon' => 'dashicons-download',
                'description' => __('eBooks, templates, software, courses', 'woocommerce-simplified'),
                'demo_products' => 8,
                'features' => array('Instant download', 'License keys', 'File versioning', 'Preview system'),
            ),
            'beauty' => array(
                'name' => __('Beauty & Wellness', 'woocommerce-simplified'),
                'icon' => 'dashicons-heart',
                'description' => __('Skincare, makeup, and health products', 'woocommerce-simplified'),
                'demo_products' => 10,
                'features' => array('Ingredient lists', 'Before/after', 'Skin quiz', 'Subscriptions'),
            ),
            'home' => array(
                'name' => __('Home & Decor', 'woocommerce-simplified'),
                'icon' => 'dashicons-admin-home',
                'description' => __('Furniture, lighting, and home accessories', 'woocommerce-simplified'),
                'demo_products' => 12,
                'features' => array('Room visualization', 'Bulk orders', 'Dimensions', 'Materials'),
            ),
            'courses' => array(
                'name' => __('Courses & Coaching', 'woocommerce-simplified'),
                'icon' => 'dashicons-welcome-learn-more',
                'description' => __('Online courses, coaching, and memberships', 'woocommerce-simplified'),
                'demo_products' => 6,
                'features' => array('Course curriculum', 'Booking calendar', 'Testimonials', 'Members area'),
            ),
            'handmade' => array(
                'name' => __('Art & Handmade', 'woocommerce-simplified'),
                'icon' => 'dashicons-art',
                'description' => __('Crafts, artwork, and custom creations', 'woocommerce-simplified'),
                'demo_products' => 10,
                'features' => array('Custom orders', 'Process photos', 'Artist bio', 'Commission requests'),
            ),
            'jewelry' => array(
                'name' => __('Jewelry & Watches', 'woocommerce-simplified'),
                'icon' => 'dashicons-awards',
                'description' => __('Fine jewelry, watches, and accessories', 'woocommerce-simplified'),
                'demo_products' => 8,
                'features' => array('360° view', 'Material details', 'Size guide', 'Gift packaging'),
            ),
            'services' => array(
                'name' => __('Services & Bookings', 'woocommerce-simplified'),
                'icon' => 'dashicons-calendar-alt',
                'description' => __('Appointments, consultations, rentals', 'woocommerce-simplified'),
                'demo_products' => 5,
                'features' => array('Booking calendar', 'Staff selection', 'Time slots', 'Deposits'),
            ),
        );
    }
}
