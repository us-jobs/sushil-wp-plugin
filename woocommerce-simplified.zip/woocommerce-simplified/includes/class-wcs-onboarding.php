<?php
/**
 * WooCommerce Simplified Onboarding Wizard
 *
 * @package WooCommerce_Simplified
 */

if (!defined('ABSPATH')) {
    exit;
}

class WCS_Onboarding {
    
    /**
     * Wizard steps
     */
    private $steps = array();
    
    /**
     * Constructor
     */
    public function __construct() {
        $this->steps = array(
            'welcome' => __('Welcome', 'woocommerce-simplified'),
            'industry' => __('Industry', 'woocommerce-simplified'),
            'details' => __('Store Details', 'woocommerce-simplified'),
            'settings' => __('Business Settings', 'woocommerce-simplified'),
            'payment' => __('Payment', 'woocommerce-simplified'),
            'install' => __('Installation', 'woocommerce-simplified'),
        );
        
        add_action('admin_menu', array($this, 'add_wizard_page'));
        add_action('admin_init', array($this, 'redirect_to_wizard'));
    }
    
    /**
     * Add wizard page to admin menu
     */
    public function add_wizard_page() {
        add_dashboard_page(
            __('Store Setup Wizard', 'woocommerce-simplified'),
            __('Store Setup', 'woocommerce-simplified'),
            'manage_options',
            'wcs-wizard',
            array($this, 'render_wizard')
        );
    }
    
    /**
     * Redirect to wizard after activation
     */
    public function redirect_to_wizard() {
        if (get_transient('wcs_activation_redirect')) {
            delete_transient('wcs_activation_redirect');
            
            if (!get_option('wcs_onboarding_complete')) {
                wp_safe_redirect(admin_url('admin.php?page=wcs-wizard'));
                exit;
            }
        }
    }
    
    /**
     * Render the wizard
     */
    public function render_wizard() {
        $step = isset($_GET['step']) ? sanitize_key($_GET['step']) : 'welcome';
        
        // Validate step
        if (!array_key_exists($step, $this->steps)) {
            $step = 'welcome';
        }
        
        wp_enqueue_style('wcs-wizard', WCS_PLUGIN_URL . 'assets/css/wizard.css', array(), WCS_VERSION);
        wp_enqueue_script('wcs-wizard', WCS_PLUGIN_URL . 'assets/js/wizard.js', array('jquery'), WCS_VERSION, true);
        
        // Localize script
        wp_localize_script('wcs-wizard', 'wcsWizard', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('wcs-wizard'),
            'industries' => WCS_Installer::get_industries(),
        ));
        
        ?>
        <div class="wcs-wizard-wrapper">
            <?php $this->render_header($step); ?>
            <div class="wcs-wizard-content">
                <?php
                $method = 'render_' . $step . '_step';
                if (method_exists($this, $method)) {
                    $this->$method();
                }
                ?>
            </div>
        </div>
        <?php
    }
    
    /**
     * Render wizard header with progress
     */
    private function render_header($current_step) {
        ?>
        <div class="wcs-wizard-header">
            <h1><?php _e('WooCommerce Simplified Setup', 'woocommerce-simplified'); ?></h1>
            <div class="wcs-progress-bar">
                <?php
                $step_number = 1;
                foreach ($this->steps as $step_key => $step_name) {
                    $classes = array('step');
                    
                    $current_index = array_search($current_step, array_keys($this->steps));
                    $this_index = array_search($step_key, array_keys($this->steps));
                    
                    if ($this_index < $current_index) {
                        $classes[] = 'complete';
                    } elseif ($step_key === $current_step) {
                        $classes[] = 'active';
                    }
                    
                    printf(
                        '<div class="%s" data-step="%s"><span class="step-number">%d</span><span class="step-name">%s</span></div>',
                        esc_attr(implode(' ', $classes)),
                        esc_attr($step_key),
                        $step_number,
                        esc_html($step_name)
                    );
                    $step_number++;
                }
                ?>
            </div>
        </div>
        <?php
    }
    
    /**
     * Step 1: Welcome
     */
    private function render_welcome_step() {
        ?>
        <div class="wcs-step wcs-step-welcome">
            <div class="wcs-welcome-content">
                <div class="wcs-welcome-icon">
                    <span class="dashicons dashicons-store"></span>
                </div>
                <h2><?php _e('Welcome to WooCommerce Simplified!', 'woocommerce-simplified'); ?></h2>
                <p class="lead"><?php _e('Let\'s set up your professional online store in just 5 minutes.', 'woocommerce-simplified'); ?></p>
                
                <div class="wcs-features">
                    <div class="feature">
                        <span class="dashicons dashicons-yes-alt"></span>
                        <strong><?php _e('Industry-Specific Templates', 'woocommerce-simplified'); ?></strong>
                        <p><?php _e('Pre-designed for your business type', 'woocommerce-simplified'); ?></p>
                    </div>
                    <div class="feature">
                        <span class="dashicons dashicons-yes-alt"></span>
                        <strong><?php _e('Demo Products Included', 'woocommerce-simplified'); ?></strong>
                        <p><?php _e('See exactly how your store will look', 'woocommerce-simplified'); ?></p>
                    </div>
                    <div class="feature">
                        <span class="dashicons dashicons-yes-alt"></span>
                        <strong><?php _e('Easy Customization', 'woocommerce-simplified'); ?></strong>
                        <p><?php _e('Your brand colors and logo', 'woocommerce-simplified'); ?></p>
                    </div>
                </div>
                
                <div class="wcs-start-options">
                    <label class="wcs-radio-card">
                        <input type="radio" name="start_mode" value="fresh" checked>
                        <div class="radio-card-content">
                            <strong><?php _e('I\'m starting fresh', 'woocommerce-simplified'); ?></strong>
                            <p><?php _e('Set up a new store with demo products', 'woocommerce-simplified'); ?></p>
                        </div>
                    </label>
                    
                    <label class="wcs-radio-card">
                        <input type="radio" name="start_mode" value="existing">
                        <div class="radio-card-content">
                            <strong><?php _e('I already have products', 'woocommerce-simplified'); ?></strong>
                            <p><?php _e('Just set up the theme and pages', 'woocommerce-simplified'); ?></p>
                        </div>
                    </label>
                </div>
            </div>
            
            <?php $this->render_navigation('', 'industry'); ?>
        </div>
        <?php
    }
    
    /**
     * Step 2: Industry Selection
     */
    private function render_industry_step() {
        $industries = WCS_Installer::get_industries();
        ?>
        <div class="wcs-step wcs-step-industry">
            <h2><?php _e('What will you sell?', 'woocommerce-simplified'); ?></h2>
            <p class="subtitle"><?php _e('Choose the industry that best matches your business', 'woocommerce-simplified'); ?></p>
            
            <div class="wcs-industry-grid">
                <?php foreach ($industries as $key => $industry): ?>
                    <div class="wcs-industry-card" data-industry="<?php echo esc_attr($key); ?>">
                        <div class="industry-icon">
                            <span class="dashicons <?php echo esc_attr($industry['icon']); ?>"></span>
                        </div>
                        <h3><?php echo esc_html($industry['name']); ?></h3>
                        <p><?php echo esc_html($industry['description']); ?></p>
                        <div class="industry-features">
                            <small><?php echo esc_html($industry['demo_products']); ?> <?php _e('demo products', 'woocommerce-simplified'); ?></small>
                        </div>
                        <button class="button button-secondary view-demo" data-industry="<?php echo esc_attr($key); ?>">
                            <?php _e('Preview Demo', 'woocommerce-simplified'); ?>
                        </button>
                    </div>
                <?php endforeach; ?>
            </div>
            
            <input type="hidden" name="selected_industry" id="selected_industry" value="">
            
            <?php $this->render_navigation('welcome', 'details'); ?>
        </div>
        <?php
    }
    
    /**
     * Step 3: Store Details
     */
    private function render_details_step() {
        $store_name = get_option('wcs_store_name', get_bloginfo('name'));
        $store_tagline = get_option('wcs_store_tagline', get_bloginfo('description'));
        ?>
        <div class="wcs-step wcs-step-details">
            <h2><?php _e('Tell us about your store', 'woocommerce-simplified'); ?></h2>
            
            <div class="wcs-form">
                <div class="form-group">
                    <label for="store_name"><?php _e('Store Name', 'woocommerce-simplified'); ?> <span class="required">*</span></label>
                    <input type="text" id="store_name" name="store_name" class="regular-text" value="<?php echo esc_attr($store_name); ?>" required>
                    <p class="description"><?php _e('This will be displayed in your store header and emails', 'woocommerce-simplified'); ?></p>
                </div>
                
                <div class="form-group">
                    <label for="store_tagline"><?php _e('Tagline', 'woocommerce-simplified'); ?></label>
                    <input type="text" id="store_tagline" name="store_tagline" class="regular-text" value="<?php echo esc_attr($store_tagline); ?>">
                    <p class="description"><?php _e('A brief description of your store', 'woocommerce-simplified'); ?></p>
                </div>
                
                <div class="form-group">
                    <label><?php _e('Store Logo', 'woocommerce-simplified'); ?></label>
                    <div class="wcs-logo-upload">
                        <div id="logo-preview" class="logo-preview">
                            <?php if (has_custom_logo()): ?>
                                <?php the_custom_logo(); ?>
                            <?php else: ?>
                                <span class="dashicons dashicons-format-image"></span>
                            <?php endif; ?>
                        </div>
                        <button type="button" class="button" id="upload-logo"><?php _e('Upload Logo', 'woocommerce-simplified'); ?></button>
                        <button type="button" class="button" id="skip-logo" style="margin-left: 10px;"><?php _e('Skip for now', 'woocommerce-simplified'); ?></button>
                        <input type="hidden" id="logo_id" name="logo_id" value="">
                    </div>
                    <p class="description"><?php _e('Recommended size: 200x80 pixels', 'woocommerce-simplified'); ?></p>
                </div>
                
                <div class="form-group">
                    <label><?php _e('Brand Colors', 'woocommerce-simplified'); ?></label>
                    <div class="wcs-color-picker-group">
                        <div class="color-picker-item">
                            <label for="primary_color"><?php _e('Primary Color', 'woocommerce-simplified'); ?></label>
                            <input type="text" id="primary_color" name="primary_color" class="wcs-color-picker" value="#FF6B6B">
                        </div>
                        <div class="color-picker-item">
                            <label for="secondary_color"><?php _e('Secondary Color', 'woocommerce-simplified'); ?></label>
                            <input type="text" id="secondary_color" name="secondary_color" class="wcs-color-picker" value="#4ECDC4">
                        </div>
                    </div>
                    
                    <div class="color-presets">
                        <p><?php _e('Or choose a preset:', 'woocommerce-simplified'); ?></p>
                        <button type="button" class="color-preset" data-primary="#FF6B6B" data-secondary="#4ECDC4">
                            <span style="background: #FF6B6B"></span>
                            <span style="background: #4ECDC4"></span>
                            <?php _e('Bold & Modern', 'woocommerce-simplified'); ?>
                        </button>
                        <button type="button" class="color-preset" data-primary="#2D6A4F" data-secondary="#95D5B2">
                            <span style="background: #2D6A4F"></span>
                            <span style="background: #95D5B2"></span>
                            <?php _e('Calm & Natural', 'woocommerce-simplified'); ?>
                        </button>
                        <button type="button" class="color-preset" data-primary="#1A1A2E" data-secondary="#D4AF37">
                            <span style="background: #1A1A2E"></span>
                            <span style="background: #D4AF37"></span>
                            <?php _e('Luxury & Elegant', 'woocommerce-simplified'); ?>
                        </button>
                        <button type="button" class="color-preset" data-primary="#FF6B9D" data-secondary="#FEC601">
                            <span style="background: #FF6B9D"></span>
                            <span style="background: #FEC601"></span>
                            <?php _e('Fun & Playful', 'woocommerce-simplified'); ?>
                        </button>
                    </div>
                </div>
            </div>
            
            <?php $this->render_navigation('industry', 'settings'); ?>
        </div>
        <?php
    }
    
    /**
     * Step 4: Business Settings
     */
    private function render_settings_step() {
        ?>
        <div class="wcs-step wcs-step-settings">
            <h2><?php _e('Business Settings', 'woocommerce-simplified'); ?></h2>
            
            <div class="wcs-form">
                <div class="form-group">
                    <label for="store_currency"><?php _e('Currency', 'woocommerce-simplified'); ?> <span class="required">*</span></label>
                    <select id="store_currency" name="store_currency" class="regular-text">
                        <?php
                        $currencies = array(
                            'USD' => 'US Dollar ($)',
                            'EUR' => 'Euro (€)',
                            'GBP' => 'British Pound (£)',
                            'CAD' => 'Canadian Dollar ($)',
                            'AUD' => 'Australian Dollar ($)',
                            'JPY' => 'Japanese Yen (¥)',
                            'INR' => 'Indian Rupee (₹)',
                        );
                        foreach ($currencies as $code => $name) {
                            printf('<option value="%s">%s</option>', esc_attr($code), esc_html($name));
                        }
                        ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="store_country"><?php _e('Store Location', 'woocommerce-simplified'); ?> <span class="required">*</span></label>
                    <select id="store_country" name="store_country" class="regular-text">
                        <option value="US"><?php _e('United States', 'woocommerce-simplified'); ?></option>
                        <option value="CA"><?php _e('Canada', 'woocommerce-simplified'); ?></option>
                        <option value="GB"><?php _e('United Kingdom', 'woocommerce-simplified'); ?></option>
                        <option value="AU"><?php _e('Australia', 'woocommerce-simplified'); ?></option>
                        <option value="IN"><?php _e('India', 'woocommerce-simplified'); ?></option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label><?php _e('What will you offer?', 'woocommerce-simplified'); ?></label>
                    <label class="wcs-checkbox">
                        <input type="checkbox" name="offer_physical" value="1" checked>
                        <?php _e('Physical products (shipping required)', 'woocommerce-simplified'); ?>
                    </label>
                    <label class="wcs-checkbox">
                        <input type="checkbox" name="offer_digital" value="1">
                        <?php _e('Digital downloads', 'woocommerce-simplified'); ?>
                    </label>
                    <label class="wcs-checkbox">
                        <input type="checkbox" name="offer_services" value="1">
                        <?php _e('Services or appointments', 'woocommerce-simplified'); ?>
                    </label>
                </div>
                
                <div class="form-group shipping-options">
                    <label><?php _e('Shipping', 'woocommerce-simplified'); ?></label>
                    <label class="wcs-radio">
                        <input type="radio" name="shipping_type" value="flat" checked>
                        <strong><?php _e('Flat rate shipping', 'woocommerce-simplified'); ?></strong>
                        <input type="number" name="flat_rate" min="0" step="0.01" value="5.00" style="width: 100px; margin-left: 10px;">
                    </label>
                    <label class="wcs-radio">
                        <input type="radio" name="shipping_type" value="free">
                        <strong><?php _e('Free shipping', 'woocommerce-simplified'); ?></strong>
                    </label>
                    <label class="wcs-radio">
                        <input type="radio" name="shipping_type" value="later">
                        <strong><?php _e('I\'ll set this up later', 'woocommerce-simplified'); ?></strong>
                    </label>
                </div>
            </div>
            
            <?php $this->render_navigation('details', 'payment'); ?>
        </div>
        <?php
    }
    
    /**
     * Step 5: Payment Setup
     */
    private function render_payment_step() {
        ?>
        <div class="wcs-step wcs-step-payment">
            <h2><?php _e('Payment Methods', 'woocommerce-simplified'); ?></h2>
            <p class="subtitle"><?php _e('Choose how you want to accept payments', 'woocommerce-simplified'); ?></p>
            
            <div class="wcs-payment-methods">
                <label class="wcs-payment-card">
                    <input type="checkbox" name="payment_stripe" value="1" checked>
                    <div class="payment-card-content">
                        <div class="payment-logo">
                            <img src="<?php echo esc_url(WCS_PLUGIN_URL . 'assets/images/stripe-logo.png'); ?>" alt="Stripe">
                        </div>
                        <div class="payment-info">
                            <strong><?php _e('Credit/Debit Cards (Stripe)', 'woocommerce-simplified'); ?></strong>
                            <p><?php _e('Accept all major cards. 2.9% + 30¢ per transaction', 'woocommerce-simplified'); ?></p>
                            <span class="badge recommended"><?php _e('Most Popular', 'woocommerce-simplified'); ?></span>
                        </div>
                    </div>
                </label>
                
                <label class="wcs-payment-card">
                    <input type="checkbox" name="payment_paypal" value="1">
                    <div class="payment-card-content">
                        <div class="payment-logo">
                            <img src="<?php echo esc_url(WCS_PLUGIN_URL . 'assets/images/paypal-logo.png'); ?>" alt="PayPal">
                        </div>
                        <div class="payment-info">
                            <strong><?php _e('PayPal', 'woocommerce-simplified'); ?></strong>
                            <p><?php _e('Let customers pay with their PayPal account', 'woocommerce-simplified'); ?></p>
                        </div>
                    </div>
                </label>
                
                <label class="wcs-payment-card">
                    <input type="checkbox" name="payment_bank" value="1">
                    <div class="payment-card-content">
                        <div class="payment-icon">
                            <span class="dashicons dashicons-bank"></span>
                        </div>
                        <div class="payment-info">
                            <strong><?php _e('Direct Bank Transfer', 'woocommerce-simplified'); ?></strong>
                            <p><?php _e('Customers pay directly into your bank account', 'woocommerce-simplified'); ?></p>
                        </div>
                    </div>
                </label>
                
                <label class="wcs-payment-card">
                    <input type="checkbox" name="payment_cod" value="1">
                    <div class="payment-card-content">
                        <div class="payment-icon">
                            <span class="dashicons dashicons-money-alt"></span>
                        </div>
                        <div class="payment-info">
                            <strong><?php _e('Cash on Delivery', 'woocommerce-simplified'); ?></strong>
                            <p><?php _e('Payment collected when order is delivered', 'woocommerce-simplified'); ?></p>
                        </div>
                    </div>
                </label>
            </div>
            
            <div class="wcs-payment-note">
                <p><strong><?php _e('Note:', 'woocommerce-simplified'); ?></strong> <?php _e('You can configure payment gateway settings after setup is complete.', 'woocommerce-simplified'); ?></p>
            </div>
            
            <?php $this->render_navigation('settings', 'install'); ?>
        </div>
        <?php
    }
    
    /**
     * Step 6: Installation
     */
    private function render_install_step() {
        ?>
        <div class="wcs-step wcs-step-install">
            <div class="wcs-install-progress">
                <div class="install-icon">
                    <span class="dashicons dashicons-update-alt wcs-spinner"></span>
                </div>
                <h2 id="install-status"><?php _e('Building your store...', 'woocommerce-simplified'); ?></h2>
                <div class="progress-steps" id="progress-steps">
                    <div class="progress-step" data-step="theme">
                        <span class="dashicons dashicons-minus"></span>
                        <?php _e('Installing theme...', 'woocommerce-simplified'); ?>
                    </div>
                    <div class="progress-step" data-step="pages">
                        <span class="dashicons dashicons-minus"></span>
                        <?php _e('Creating pages...', 'woocommerce-simplified'); ?>
                    </div>
                    <div class="progress-step" data-step="products">
                        <span class="dashicons dashicons-minus"></span>
                        <?php _e('Adding demo products...', 'woocommerce-simplified'); ?>
                    </div>
                    <div class="progress-step" data-step="settings">
                        <span class="dashicons dashicons-minus"></span>
                        <?php _e('Configuring settings...', 'woocommerce-simplified'); ?>
                    </div>
                    <div class="progress-step" data-step="navigation">
                        <span class="dashicons dashicons-minus"></span>
                        <?php _e('Setting up navigation...', 'woocommerce-simplified'); ?>
                    </div>
                </div>
                
                <div class="progress-bar">
                    <div class="progress-fill" id="progress-fill" style="width: 0%"></div>
                </div>
                <p class="progress-text"><span id="progress-percent">0</span>% <?php _e('complete', 'woocommerce-simplified'); ?></p>
            </div>
            
            <div class="wcs-install-complete" id="install-complete" style="display: none;">
                <div class="success-icon">
                    <span class="dashicons dashicons-yes-alt"></span>
                </div>
                <h2><?php _e('Your store is ready!', 'woocommerce-simplified'); ?></h2>
                <p><?php _e('Congratulations! Your professional online store has been set up successfully.', 'woocommerce-simplified'); ?></p>
                
                <div class="wcs-next-steps">
                    <h3><?php _e('What\'s Next?', 'woocommerce-simplified'); ?></h3>
                    <div class="next-step-item">
                        <span class="dashicons dashicons-yes-alt"></span>
                        <strong><?php _e('Replace demo products', 'woocommerce-simplified'); ?></strong>
                        <p><?php _e('Add your own products or keep demos as templates', 'woocommerce-simplified'); ?></p>
                    </div>
                    <div class="next-step-item">
                        <span class="dashicons dashicons-yes-alt"></span>
                        <strong><?php _e('Customize your design', 'woocommerce-simplified'); ?></strong>
                        <p><?php _e('Fine-tune colors, fonts, and layout', 'woocommerce-simplified'); ?></p>
                    </div>
                    <div class="next-step-item">
                        <span class="dashicons dashicons-yes-alt"></span>
                        <strong><?php _e('Test checkout', 'woocommerce-simplified'); ?></strong>
                        <p><?php _e('Make sure everything works smoothly', 'woocommerce-simplified'); ?></p>
                    </div>
                </div>
                
                <div class="wcs-action-buttons">
                    <a href="<?php echo esc_url(home_url('/')); ?>" class="button button-primary button-hero" target="_blank">
                        <?php _e('View Your Store', 'woocommerce-simplified'); ?>
                    </a>
                    <a href="<?php echo esc_url(admin_url('admin.php?page=wcs-dashboard')); ?>" class="button button-secondary button-hero">
                        <?php _e('Go to Dashboard', 'woocommerce-simplified'); ?>
                    </a>
                </div>
            </div>
        </div>
        <?php
    }
    
    /**
     * Render navigation buttons
     */
    private function render_navigation($prev_step, $next_step) {
        ?>
        <div class="wcs-wizard-actions">
            <?php if ($prev_step): ?>
                <a href="<?php echo esc_url(add_query_arg('step', $prev_step)); ?>" class="button button-secondary wcs-btn-back">
                    <span class="dashicons dashicons-arrow-left-alt2"></span>
                    <?php _e('Back', 'woocommerce-simplified'); ?>
                </a>
            <?php endif; ?>
            
            <button type="button" class="button button-primary wcs-btn-next" data-next-step="<?php echo esc_attr($next_step); ?>">
                <?php
                if ($next_step === 'install') {
                    _e('Install My Store', 'woocommerce-simplified');
                } else {
                    _e('Continue', 'woocommerce-simplified');
                }
                ?>
                <span class="dashicons dashicons-arrow-right-alt2"></span>
            </button>
            
            <?php if ($next_step !== 'install'): ?>
                <a href="#" class="wcs-skip-wizard"><?php _e('Skip wizard', 'woocommerce-simplified'); ?></a>
            <?php endif; ?>
        </div>
        <?php
    }
}
