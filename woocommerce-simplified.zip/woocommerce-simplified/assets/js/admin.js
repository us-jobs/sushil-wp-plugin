/**
 * WooCommerce Simplified Admin JS
 */

jQuery(document).ready(function($) {
    'use strict';
    
    // Initialize color pickers
    if ($.fn.wpColorPicker) {
        $('.wcs-color-field').wpColorPicker();
    }
    
    // Remove demo content
    $('#wcs-remove-demo').on('click', function(e) {
        e.preventDefault();
        
        if (!confirm(wcsAdmin.strings.confirm_remove_demo)) {
            return;
        }
        
        const $btn = $(this);
        const originalText = $btn.text();
        
        $btn.text(wcsAdmin.strings.removing).prop('disabled', true);
        
        $.ajax({
            url: wcsAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'wcs_remove_demo_content',
                nonce: wcsAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    alert(response.data.message);
                    location.reload();
                } else {
                    alert(response.data.message || 'Error removing demo content');
                    $btn.text(originalText).prop('disabled', false);
                }
            },
            error: function() {
                alert('Error removing demo content');
                $btn.text(originalText).prop('disabled', false);
            }
        });
    });
    
    // Reset wizard
    $('#wcs-reset-wizard').on('click', function(e) {
        e.preventDefault();
        
        if (!confirm('Are you sure you want to reset the setup wizard? This will clear all your setup preferences.')) {
            return;
        }
        
        const $btn = $(this);
        const originalText = $btn.text();
        
        $btn.text('Resetting...').prop('disabled', true);
        
        $.ajax({
            url: wcsAdmin.ajaxurl,
            type: 'POST',
            data: {
                action: 'wcs_reset_wizard',
                nonce: wcsAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    window.location.href = response.data.redirect;
                } else {
                    alert(response.data.message || 'Error resetting wizard');
                    $btn.text(originalText).prop('disabled', false);
                }
            },
            error: function() {
                alert('Error resetting wizard');
                $btn.text(originalText).prop('disabled', false);
            }
        });
    });
    
    // Dismiss setup notice
    $(document).on('click', '.wcs-setup-notice .notice-dismiss', function() {
        $.post(wcsAdmin.ajaxurl, {
            action: 'wcs_dismiss_setup_notice',
            nonce: wcsAdmin.nonce
        });
    });
});
