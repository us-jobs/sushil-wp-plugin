/**
 * WooCommerce Simplified Wizard JS
 */

jQuery(document).ready(function($) {
    'use strict';
    
    const WCSWizard = {
        currentStep: 'welcome',
        selectedIndustry: '',
        wizardData: {},
        
        init: function() {
            this.bindEvents();
            this.initColorPickers();
            this.initMediaUploader();
        },
        
        bindEvents: function() {
            // Industry card selection
            $(document).on('click', '.wcs-industry-card', this.selectIndustry.bind(this));
            
            // Preview demo button
            $(document).on('click', '.view-demo', this.viewDemo.bind(this));
            
            // Color preset selection
            $(document).on('click', '.color-preset', this.selectColorPreset.bind(this));
            
            // Navigation buttons
            $(document).on('click', '.wcs-btn-next', this.handleNext.bind(this));
            
            // Radio card selection
            $(document).on('change', '.wcs-radio-card input[type="radio"]', this.selectRadioCard);
            
            // Skip wizard
            $(document).on('click', '.wcs-skip-wizard', this.skipWizard);
            
            // Auto-start installation on install step
            if ($('.wcs-step-install').length) {
                this.startInstallation();
            }
        },
        
        selectIndustry: function(e) {
            e.preventDefault();
            const $card = $(e.currentTarget);
            const industry = $card.data('industry');
            
            // Remove previous selection
            $('.wcs-industry-card').removeClass('selected');
            
            // Mark as selected
            $card.addClass('selected');
            
            // Store selection
            this.selectedIndustry = industry;
            $('#selected_industry').val(industry);
            
            // Enable next button
            $('.wcs-btn-next').prop('disabled', false);
        },
        
        viewDemo: function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            const industry = $(e.currentTarget).data('industry');
            
            // Show loading
            $(e.currentTarget).text('Loading...').prop('disabled', true);
            
            // Get preview data
            $.ajax({
                url: wcsWizard.ajaxurl,
                type: 'POST',
                data: {
                    action: 'wcs_get_industry_preview',
                    nonce: wcsWizard.nonce,
                    industry: industry
                },
                success: function(response) {
                    if (response.success) {
                        WCSWizard.showPreviewModal(industry, response.data);
                    }
                },
                complete: function() {
                    $(e.currentTarget).text('Preview Demo').prop('disabled', false);
                }
            });
        },
        
        showPreviewModal: function(industry, data) {
            const modal = $('<div class="wcs-modal-overlay"><div class="wcs-modal">' +
                '<button class="wcs-modal-close">&times;</button>' +
                '<h2>' + data.industry.name + '</h2>' +
                '<img src="' + data.preview_image + '" alt="Preview" onerror="this.src=\'' + wcsWizard.pluginUrl + 'assets/images/placeholder.jpg\'">' +
                '<div class="wcs-modal-features">' +
                '<h3>Features:</h3>' +
                '<ul>' +
                data.industry.features.map(f => '<li>' + f + '</li>').join('') +
                '</ul>' +
                '</div>' +
                '<button class="button button-primary wcs-select-industry" data-industry="' + industry + '">Select This Industry</button>' +
                '</div></div>');
            
            $('body').append(modal);
            modal.fadeIn(200);
            
            // Close modal events
            modal.on('click', '.wcs-modal-close, .wcs-modal-overlay', function(e) {
                if (e.target === this) {
                    modal.fadeOut(200, function() { $(this).remove(); });
                }
            });
            
            // Select industry from modal
            modal.on('click', '.wcs-select-industry', function() {
                const industry = $(this).data('industry');
                $('.wcs-industry-card[data-industry="' + industry + '"]').click();
                modal.fadeOut(200, function() { $(this).remove(); });
            });
        },
        
        selectColorPreset: function(e) {
            e.preventDefault();
            const $btn = $(e.currentTarget);
            const primary = $btn.data('primary');
            const secondary = $btn.data('secondary');
            
            $('#primary_color').val(primary).trigger('change');
            $('#secondary_color').val(secondary).trigger('change');
        },
        
        selectRadioCard: function() {
            $('.wcs-radio-card').removeClass('selected');
            $(this).closest('.wcs-radio-card').addClass('selected');
        },
        
        handleNext: function(e) {
            e.preventDefault();
            const $btn = $(e.currentTarget);
            const nextStep = $btn.data('next-step');
            
            // Validate current step
            if (!this.validateStep()) {
                return;
            }
            
            // Collect step data
            const stepData = this.collectStepData();
            
            // Save step data via AJAX if not the install step
            if (nextStep !== 'install') {
                this.saveStepData(stepData, function() {
                    window.location.href = window.location.pathname + '?page=wcs-wizard&step=' + nextStep;
                });
            } else {
                // Go to install step
                window.location.href = window.location.pathname + '?page=wcs-wizard&step=install';
            }
        },
        
        validateStep: function() {
            const $step = $('.wcs-step:visible');
            let valid = true;
            let message = '';
            
            // Industry step
            if ($step.hasClass('wcs-step-industry')) {
                if (!this.selectedIndustry && !$('#selected_industry').val()) {
                    message = 'Please select an industry';
                    valid = false;
                }
            }
            
            // Details step
            if ($step.hasClass('wcs-step-details')) {
                const storeName = $('#store_name').val();
                if (!storeName || storeName.trim() === '') {
                    message = 'Please enter a store name';
                    valid = false;
                }
            }
            
            if (!valid) {
                alert(message);
            }
            
            return valid;
        },
        
        collectStepData: function() {
            const $step = $('.wcs-step:visible');
            let data = {};
            let step = '';
            
            // Determine current step
            if ($step.hasClass('wcs-step-industry')) {
                step = 'industry';
                data = {
                    industry: $('#selected_industry').val() || this.selectedIndustry,
                    start_mode: $('input[name="start_mode"]:checked').val()
                };
            } else if ($step.hasClass('wcs-step-details')) {
                step = 'details';
                data = {
                    store_name: $('#store_name').val(),
                    store_tagline: $('#store_tagline').val(),
                    logo_id: $('#logo_id').val(),
                    primary_color: $('#primary_color').val(),
                    secondary_color: $('#secondary_color').val()
                };
            } else if ($step.hasClass('wcs-step-settings')) {
                step = 'settings';
                data = {
                    currency: $('#store_currency').val(),
                    country: $('#store_country').val(),
                    offer_physical: $('input[name="offer_physical"]').is(':checked') ? 1 : 0,
                    offer_digital: $('input[name="offer_digital"]').is(':checked') ? 1 : 0,
                    offer_services: $('input[name="offer_services"]').is(':checked') ? 1 : 0,
                    shipping_type: $('input[name="shipping_type"]:checked').val(),
                    flat_rate: $('input[name="flat_rate"]').val()
                };
            } else if ($step.hasClass('wcs-step-payment')) {
                step = 'payment';
                data = {
                    payment_stripe: $('input[name="payment_stripe"]').is(':checked') ? 1 : 0,
                    payment_paypal: $('input[name="payment_paypal"]').is(':checked') ? 1 : 0,
                    payment_bank: $('input[name="payment_bank"]').is(':checked') ? 1 : 0,
                    payment_cod: $('input[name="payment_cod"]').is(':checked') ? 1 : 0
                };
            }
            
            return {
                step: step,
                data: data
            };
        },
        
        saveStepData: function(stepData, callback) {
            $.ajax({
                url: wcsWizard.ajaxurl,
                type: 'POST',
                data: {
                    action: 'wcs_save_wizard_step',
                    nonce: wcsWizard.nonce,
                    step: stepData.step,
                    data: stepData.data
                },
                success: function(response) {
                    if (response.success && callback) {
                        callback();
                    }
                }
            });
        },
        
        startInstallation: function() {
            const steps = ['theme', 'pages', 'products', 'settings', 'navigation'];
            let currentStepIndex = 0;
            
            const updateProgress = function(step, status) {
                const $step = $('.progress-step[data-step="' + step + '"]');
                const icon = status === 'complete' ? 'dashicons-yes-alt' : 'dashicons-minus';
                $step.find('.dashicons').removeClass('dashicons-minus dashicons-update-alt').addClass(icon);
                
                if (status === 'complete') {
                    $step.addClass('complete');
                }
            };
            
            const processStep = function() {
                if (currentStepIndex >= steps.length) {
                    // Installation complete
                    $('#install-status').text('Installation Complete!');
                    $('#progress-fill').css('width', '100%');
                    $('#progress-percent').text('100');
                    
                    setTimeout(function() {
                        $('#install-complete').fadeIn();
                        $('.wcs-install-progress').fadeOut();
                    }, 1000);
                    return;
                }
                
                const step = steps[currentStepIndex];
                const progress = ((currentStepIndex + 1) / steps.length) * 100;
                
                updateProgress(step, 'complete');
                $('#progress-fill').css('width', progress + '%');
                $('#progress-percent').text(Math.round(progress));
                
                currentStepIndex++;
                setTimeout(processStep, 800); // Simulate step processing
            };
            
            // Start installation via AJAX
            $.ajax({
                url: wcsWizard.ajaxurl,
                type: 'POST',
                data: {
                    action: 'wcs_install_template',
                    nonce: wcsWizard.nonce
                },
                success: function(response) {
                    if (response.success) {
                        processStep();
                    } else {
                        alert('Installation failed: ' + (response.data.message || 'Unknown error'));
                    }
                },
                error: function() {
                    alert('Installation failed. Please try again.');
                }
            });
        },
        
        skipWizard: function(e) {
            e.preventDefault();
            if (confirm('Are you sure you want to skip the wizard? You can run it again later from the plugin settings.')) {
                window.location.href = wcsWizard.dashboardUrl;
            }
        },
        
        initColorPickers: function() {
            if ($.fn.wpColorPicker) {
                $('.wcs-color-picker').wpColorPicker();
            }
        },
        
        initMediaUploader: function() {
            let mediaUploader;
            
            $('#upload-logo').on('click', function(e) {
                e.preventDefault();
                
                if (mediaUploader) {
                    mediaUploader.open();
                    return;
                }
                
                mediaUploader = wp.media({
                    title: 'Choose Logo',
                    button: {
                        text: 'Use this logo'
                    },
                    multiple: false
                });
                
                mediaUploader.on('select', function() {
                    const attachment = mediaUploader.state().get('selection').first().toJSON();
                    $('#logo_id').val(attachment.id);
                    $('#logo-preview').html('<img src="' + attachment.url + '" style="max-width: 200px;">');
                });
                
                mediaUploader.open();
            });
            
            $('#skip-logo').on('click', function(e) {
                e.preventDefault();
                $('#logo_id').val('');
            });
        }
    };
    
    // Initialize
    WCSWizard.init();
});
