<?php
/**
 * Fashion Industry Template Configuration
 */

return array(
    'name' => 'Fashion & Apparel',
    'slug' => 'fashion',
    'theme' => 'storefront', // Theme to install/activate
    
    'colors' => array(
        'primary' => '#1a1a1a',
        'secondary' => '#d4af37',
    ),
    
    'pages' => array(
        'about' => 'About Us',
        'contact' => 'Contact',
        'shipping' => 'Shipping & Returns',
        'size-guide' => 'Size Guide',
    ),
    
    'menu_items' => array(
        'primary' => array(
            'Home',
            'Shop',
            'New Arrivals',
            'Sale',
            'About',
            'Contact',
        ),
        'footer' => array(
            'Shipping & Returns',
            'Size Guide',
            'Privacy Policy',
            'Terms & Conditions',
        ),
    ),
    
    'widgets' => array(
        'sidebar' => array(
            'woocommerce_product_categories',
            'woocommerce_price_filter',
            'woocommerce_layered_nav',
        ),
    ),
    
    'demo_products_count' => 12,
    
    'features' => array(
        'size_variations' => true,
        'color_swatches' => true,
        'quick_view' => true,
        'wishlist' => true,
        'lookbook' => true,
    ),
);
